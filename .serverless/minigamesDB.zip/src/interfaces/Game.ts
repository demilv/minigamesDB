export interface Game{
    _id: string,
    name: string,
    bImage: string,
    price: number,
    status: boolean
}